package br.org.scadabr.api;

import junit.framework.TestCase;

public class WriteDataTest extends TestCase {

	public void testParams() {
		assertTrue(true);
	}
}
