package br.org.scadabr.api;

import junit.framework.TestCase;

public class AnnotateEventTest extends TestCase {

	public void testParams() {
		assertTrue(true);
	}
}
