package br.org.scadabr.api;

import junit.framework.TestCase;

public class AckEventsTest extends TestCase {

	public void testParams() {
		assertTrue(true);
	}
}
