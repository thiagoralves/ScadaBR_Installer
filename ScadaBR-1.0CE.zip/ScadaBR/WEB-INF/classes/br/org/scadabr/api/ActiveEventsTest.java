package br.org.scadabr.api;

import junit.framework.TestCase;

public class ActiveEventsTest extends TestCase {

	public void testParams() {
		assertTrue(true);
	}
}