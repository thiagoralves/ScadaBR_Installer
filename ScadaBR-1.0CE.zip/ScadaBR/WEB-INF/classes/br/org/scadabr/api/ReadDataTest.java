package br.org.scadabr.api;

import junit.framework.TestCase;

public class ReadDataTest extends TestCase {

	public void testParams() {
		assertTrue(true);
	}

}
