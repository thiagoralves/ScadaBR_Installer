/*
	Copyright (c) 2004-2006, The Dojo Foundation
	All Rights Reserved.

	Licensed under the Academic Free License version 2.1 or above OR the
	modified BSD license. For more information on Dojo licensing, see:

		http://dojotoolkit.org/community/licensing.shtml
*/



({"displayName":"\u092d\u093e\u0930\u0924\u0940\u092f  \u0930\u0942\u092a\u092f\u093e", "symbol":"\u0930\ufffd?."})